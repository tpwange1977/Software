def cau(type, n1, n2):
    
    if type == 1:
        a = n1 + n2

    elif type == 2:
        a = n1 - n2

    else:
        a = n1 * n2
    
    return a