import src.cau as cau
import pytest

#class Test_cover:

def first_entry():
    return "a"


def test_add():
    a = cau.compute(1,2,3)
    assert a==5
  
def test_minus():
    a = cau.compute(2,2,3)
    assert a==-1        
