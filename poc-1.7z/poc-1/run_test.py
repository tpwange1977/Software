#!/usr/bin/env ```python
# -*- coding: utf-8 -*-
import pytest
import pytest_cov

if __name__=='__main__':
  pytest.main(["--cov=./src/" ,"--cov-report=html","--cov-config=./src/.coveragerc"] )

# pytest --cov=./src/ --durations=0 -vv --cache-clear --color=yes --junit-xml=path --cov-report html --cov-config ./src/.coveragerc
# --cache-clear --trace
# pytest --noconftest ./src --debug

#  --deselect="src/cau.py::compute2"

# =junit/test-results.xml --cov=./code/ --cov-report=xml


